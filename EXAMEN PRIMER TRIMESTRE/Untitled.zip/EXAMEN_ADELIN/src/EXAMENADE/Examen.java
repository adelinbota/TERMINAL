package EXAMENADE;

public class Examen {

	public static void main(String[] args) {
		
		//Ejercicios.Ejercicio1sumarNumeros();
		//System.out.println(Ejercicios.Ejercicio2indicarMayor(5,4,7));
		//Ejercicios.Ejercicio3alturaAsteriscos();
		//Ejercicios.Ejercicio4recibeNumero();
		//System.out.println(Ejercicios.Ejercicio6coincidirTexto("Aprueba a todos Juanfran"));
		//System.out.println(Ejercicios.Ejercicio7nombreMayus("Adelin Bota"));
		//Ejercicios.Ejercicio8letrasVector();
	}

}
